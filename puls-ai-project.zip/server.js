import "dotenv/config";
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";

app.disable("x-powered-by");
app.use(express.json({ limit: "10mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(API_KEY), model: MODEL });
});

app.post("/api/analyze-food", async (req, res) => {
  try {
    if (!API_KEY) {
      return res.status(503).json({ error: "ИИ не настроен: добавь OPENAI_API_KEY в файл .env и перезапусти сервер." });
    }
    const { imageDataUrl, portionGrams } = req.body ?? {};
    if (typeof imageDataUrl !== "string" ||
        !/^data:image\/(jpeg|jpg|png|webp|gif);base64,/i.test(imageDataUrl)) {
      return res.status(400).json({ error: "Нужна фотография в формате JPG, PNG или WebP." });
    }
    if (imageDataUrl.length > 8 * 1024 * 1024 * 1.4) {
      return res.status(413).json({ error: "Фото слишком большое. Выбери изображение меньше 8 МБ." });
    }
    const portion = Number(portionGrams);
    const portionHint = Number.isFinite(portion) && portion > 0
      ? `Пользователь указал вес порции ${Math.round(portion)} г. Используй его как подсказку, но сообщи, если это противоречит видимому.`
      : "Точный вес порции неизвестен: оцени его приблизительно и явно отметь неопределённость.";

    const prompt = `Ты помощник по питанию. Оцени блюдо на фото. ${portionHint}
Верни только JSON-объект со следующими полями:
{
 "foodName": "короткое название блюда по-русски",
 "portionGrams": число,
 "caloriesKcal": число,
 "proteinG": число,
 "fatG": число,
 "carbsG": число,
 "estimatedRange": "краткий диапазон калорий, например 350–500 ккал",
 "notes": "коротко перечисли допущения и неопределённость на русском"
}
Оцени КБЖУ для всей указанной/оценённой порции, не на 100 г. Не выдумывай точность: масло, соусы, начинка и масса по фото могут быть не видны. Если блюдо невозможно определить, объясни это в notes и дай осторожную оценку только если уместно. Не давай медицинских советов.`;

    const upstream = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        temperature: 0.2,
        max_tokens: 500,
        response_format: { type: "json_object" },
        messages: [{
          role: "user",
          content: [
            { type: "text", text: prompt },
            { type: "image_url", image_url: { url: imageDataUrl, detail: "high" } }
          ]
        }]
      })
    });

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("OpenAI API error:", upstream.status, result?.error?.message || "unknown");
      const status = upstream.status === 401 ? 502 : 502;
      return res.status(status).json({
        error: upstream.status === 401
          ? "ИИ-сервис отклонил API-ключ. Проверь OPENAI_API_KEY."
          : "ИИ-сервис вернул ошибку. Проверь ключ, доступ к модели и лимиты аккаунта."
      });
    }

    const content = result?.choices?.[0]?.message?.content;
    if (!content) return res.status(502).json({ error: "ИИ не вернул результат. Попробуй другое фото." });
    let analysis;
    try { analysis = JSON.parse(content); }
    catch { return res.status(502).json({ error: "Не удалось прочитать ответ ИИ. Попробуй ещё раз." }); }

    const numericFields = ["portionGrams", "caloriesKcal", "proteinG", "fatG", "carbsG"];
    for (const field of numericFields) {
      const n = Number(analysis[field]);
      if (!Number.isFinite(n) || n < 0 || n > 100000) {
        return res.status(502).json({ error: "ИИ вернул некорректные значения. Попробуй ещё раз." });
      }
      analysis[field] = Math.round(n * 10) / 10;
    }
    analysis.foodName = String(analysis.foodName || "Блюдо по фото").slice(0, 160);
    analysis.estimatedRange = String(analysis.estimatedRange || "").slice(0, 120);
    analysis.notes = String(analysis.notes || "Оценка по фотографии приблизительна.").slice(0, 600);
    res.json({ analysis });
  } catch (error) {
    console.error("Analysis request failed:", error?.message || error);
    res.status(500).json({ error: "Внутренняя ошибка сервера. Попробуй позже." });
  }
});

app.listen(PORT, () => {
  console.log(`ПУЛЬС запущен: http://localhost:${PORT}`);
  console.log(`ИИ: ${API_KEY ? "API-ключ найден" : "не настроен — добавь OPENAI_API_KEY в .env"}`);
});
